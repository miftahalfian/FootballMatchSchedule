package com.solitelab.footballmatchschedule.data.mvp.model

data class MatchResult (
    var events: List<Match>?
)