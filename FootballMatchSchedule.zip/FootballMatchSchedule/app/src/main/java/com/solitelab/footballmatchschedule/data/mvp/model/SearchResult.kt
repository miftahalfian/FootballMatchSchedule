package com.solitelab.footballmatchschedule.data.mvp.model

data class SearchResult (
    var event : List<Match>?
)